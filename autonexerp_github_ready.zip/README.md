# Autonex ERP

실행 방법, 설치 방법 설명